---
name: topic-tracker
description: "Tracks trending topics from user-input themes, searches latest sources, discovers recent trending topics, and generates high-quality long-form articles with fact-checking. Trigger keywords: track topic, trending, hot events, industry trends, news tracking, long-form article, content tracking"
---

# Topic Tracker

## Overview

A comprehensive content tracking and generation system that extracts core focus points from user input, conducts deep searches of latest sources, discovers recent trending topics, and produces high-quality long-form articles with fact-checking. Suitable for tracking hot events, industry trends, celebrity news, and other ongoing topics.

## Workflow

**Execute strictly in step order. No parallelization except Step 4.**

```
Step 1 → Step 2 → Step 3 → Step 4 (parallelizable) → Step 5 → Step 6
  ↓        ↓        ↓           ↓                     ↓        ↓
Understand  Search   Mine      Deep search          Write    Fact
 input     sources  topics    each topic           article   check
(serial)  (serial) (serial)  (parallelizable)     (serial) (serial)
```

### Step 1: Understand User Input [Serial]

Analyze user input to detect ambiguity and break down interests.

1. **Search before judging** — Regardless of what the user inputs, first perform a web search to understand the actual meaning of the word/phrase. Search the user's original keywords, observe what different entities/domains the word corresponds to in search results.

2. **Assess ambiguity** based on search results:

   **Ambiguity exists when:**
   - Search results show same-name entities from different domains (e.g., "Hoshino" is both an App and a singer)
   - Same word has different meanings in tech, entertainment, geography, and other domains
   - Abbreviations/shorthand correspond to multiple full names
   - English words have multiple translations or references

   **No ambiguity when:**
   - Search results are highly consistent, pointing to the same entity
   - Although there are multiple results, they are clearly different aspects of the same thing
   - User input is already specific enough (e.g., "OpenAI's ChatGPT")

3. **If ambiguity exists**: Present the different meanings to the user and ask them to confirm which one they want to track. Wait for user selection before proceeding.

4. **If no ambiguity**: Produce the following and proceed to Step 2:
   - Clear topic name, domain, and one-sentence summary
   - 3-5 questions the user might care about
   - 3+ suggested search keywords
   - Tracking parameters (time range, content type, geographic scope if applicable)

**Common high-risk ambiguity scenarios:**

| Type | Example | Possible Ambiguity |
|------|---------|-------------------|
| Person Name | John Smith, James Wang | Same-name people in different fields |
| Place Name | Springfield, Alexandria | Place vs Brand vs Street |
| Product Name | Echo, Spark | Same-name products/companies/people |
| Tech Term | antigravity | Physics concept vs Programming module |
| Abbreviation | TX, AI, BD | Multiple full names |
| English Word | Apple, Spring | Common word vs Proper noun |

**Must wait for this step to complete before entering Step 2.**

---

### Step 2: Search Sources [Serial]

Conduct multi-dimensional search based on core questions decomposed in Step 1.

**Source Priority:**
1. **Official Channels**: Government websites, official announcements, corporate press releases
2. **Authoritative Media**: Mainstream news organizations, leading industry media
3. **Professional Platforms**: Industry vertical websites, professional forums
4. **Social Media**: Twitter, Reddit, and other real-time updates (requires cross-verification)

**Search Techniques:**
- Use multiple keyword combinations for searching
- Note time constraints, prioritize getting latest information
- Cross-verify important information from multiple sources
- Read original content in depth, don't rely solely on summaries

**Information Collection Points:**
- Record complete time, place, people, events
- Preserve original data and direct quotes
- Mark credibility assessment of sources (High/Medium/Low)
- Note timeliness of information

**Output a structured source report:**

```
## Search Topic: [Topic Name]

### Source Overview
- Search Time Range: [Time Range]
- Valid Source Count: [Count]
- Core Finding: [One-sentence summary]

### Important Source List

**Source 1: [Title]**
- Origin: [Media/Website name]
- Time: [Publication time]
- Core Content: [Key information summary]
- Important Data/Quotes: [If any]
- Credibility: High/Medium/Low

**Source 2: ...**

### Information Cross-Verification
- [Important Fact 1]: Confirmed by [X] sources
- [Important Fact 2]: Single source only, cite with caution

### Search Suggestions
- Information Gaps: [Directions needing additional search]
- Controversy Points: [Content where different sources disagree]
```

**Principles:**
- Accuracy First: Better to collect less than to collect inaccurate information
- Timeliness Priority: Prioritize getting latest updates
- Multiple Perspectives: Try to collect viewpoints from different positions
- Traceability: Ensure every piece of information can be traced to original source

**Must wait for search completion before entering Step 3.**

---

### Step 3: Mine Trending Topics [Serial]

Analyze sources collected in Step 2 to mine 3-5 recent trending topics.

#### Trending Topic Standards

**Must-Meet Conditions:**

1. **Completely Relevant to Topic (Most Important)**:
   - Trending topics must be **directly related** to the user's tracked topic, no deviation allowed
   - Background, details, quotes mentioned in sources cannot be used as trending topics
   - Only the **core content** in sources can be trending topics
   - If user tracks "NBA Today Updates", cannot output irrelevant topics like "A Star Player's Childhood Story"

2. **Event Timeliness (Judge by actual occurrence time, not report time)**:
   - **Within 1 day**: Highest priority, must focus on
   - **Within 3 days**: High priority
   - **Within 5 days**: Can consider
   - **Over 5 days**: Basically no value, unless it's a major ongoing event
   - Note: Look at when the event **actually happened**, not article publication time

3. **Sufficient Information**: Enough material to support expanded writing

4. **Clear Expression**: Topic expression is accurate, detailed, unambiguous

**Bonus Points:**
- Has conflict or contrast
- Involves well-known people or organizations
- Has specific data or milestones
- Can evoke reader emotional resonance
- Has discussion potential

**Must Exclude Topics:**
- Content loosely or not related to user's topic
- Old news where event occurred over 5 days ago
- Topics that are too broad (e.g., "AI Development Trends")
- Clickbait lacking substantive content
- Background introductions, historical reviews, and other non-core content from sources

#### Mining Process

1. **Analyze Sources One by One**: Identify the single most core topic point from each source. Extract the **actual occurrence time** of the event (not report time).
2. **Relevance Assessment (Strict)**: Determine if topic is **completely relevant** to user's topic. Directly exclude loosely related topics, don't force inclusion.
3. **Timeliness Filtering**: Prioritize events within 1 day → within 3 days → within 5 days. Basically exclude anything over 5 days.
4. **Deduplication and Merging**: Merge similar or duplicate topics.
5. **Value Ranking**: Rank by relevance, timeliness, and topic appeal combined.
6. **Output Selection**: Output 3-5 most valuable trending topics.

#### Topic Expression Examples

Good topic expressions:
- "Taylor Swift's December 28th NYC Concert Tickets Hit $35,556 as Status Symbol"
- "Bankrupt Company's $1.2M IOU Starts Auction at $1"
- "Heat Officially Announce No Butler Trade"

Bad topic expressions:
- "Taylor Swift concert related" (too vague)
- "Company debt issues" (too broad)
- "NBA trade updates" (lacks specificity)

#### Topic Mining Output Format

```
## Topic Mining Report

### Analysis Process
[Brief explanation of topic points discovered from each source, and merging/filtering logic]

### Trending Topic List

**Topic 1: [Topic Title]**
- Event Occurrence Time: [Specific date, e.g., 2026-01-18]
- Timeliness Rating: [Within 1 day / Within 3 days / Within 5 days]
- Relevance to Topic: [Explain why directly related to user's topic]
- Core Appeal: [Why worth writing about]
- Related Sources: [From which sources]

**Topic 2: ...**

### Topic Priority Recommendations
1. [Most worth prioritizing and why]
2. [Second priority...]
```

**Must wait for topic mining completion before entering Step 4.**

---

### Step 4: Deep Search Trending Topics [Parallelizable]

For each trending topic mined in Step 3, conduct a deep search.

**This step can be parallelized**: Deep searches for multiple topics can proceed simultaneously using the Agent tool.

Search task for each topic:
- Obtain more detailed background information
- Collect multiple perspectives and data
- Find unique entry angles

Follow the same source search principles from Step 2 (source priority, search techniques, information collection points).

**Must wait for ALL topic searches to complete before entering Step 5.**

---

### Step 5: Write Long-form Article [Serial]

Write an 800-1500 word high-quality long-form article based on trending topics and search materials.

#### Target Readers
Young internet users who seek high information density and good reading experience.

#### Style Requirements
- **Internet Appeal**: Titles and expressions resonate with young people
- **Information Dense**: Every paragraph has substance, no filler
- **Brisk Pace**: Not dragging, not preachy
- **Clear Viewpoint**: Dare to express stance, but based on facts

#### Must Avoid
- Preachy summaries, reflections, elevations
- Stiff connectors like "firstly, secondly, finally"
- Empty future outlooks
- Excessive use of exclamation marks

#### Title Requirements
- Within 20 characters
- Precise, concise, attractive
- Not clickbait, but should create click desire

#### Structure Requirements
- Optional overview paragraph (time, place, people, event, result)
- 2-5 sections, section titles should have internet appeal
- Appropriate detail distribution, expand key sections, streamline secondary sections

#### Content Requirements
- Must include key information: time, place, people, data, product names, etc.
- Direct quotes from people, use markdown quote format
- Bold important information
- Information accurate, no fabrication, no altering facts

#### Article Format Example

```markdown
# This is a Title with Internet Appeal

Something big just happened... (overview paragraph)

## What Happened

Body content, **key data** should be bolded...

> "This is what someone actually said" — Someone

## Why Did This Happen

Analysis and background...

## What Happens Next

Future developments...
```

#### Images
- Use `images_search_and_download` tool to add 2-3 relevant images for the article

#### Output Requirements
1. Write complete article (markdown format)
2. Save as `article_[YYYYMMDD].md`
3. Use `convert_file` tool to convert to `article_[YYYYMMDD].docx`
4. Return article preview and file path

**Must wait for article writing completion before entering Step 6.**

---

### Step 6: Fact Check [Serial]

Verify accuracy of key information in the article.

#### Verification Scope

**Must Verify:**
- **Time Information**: Specific dates when events occurred
- **Data Information**: Amounts, quantities, percentages, rankings, etc.
- **Quotes**: Whether direct quotes are accurate
- **Factual Statements**: Whether event descriptions are true
- **Proper Nouns**: Product names, company names, personal names, etc.

**Can Skip:**
- Author's subjective comments and opinions
- Widely known common knowledge
- Unverifiable future predictions

#### Verification Process

1. **Statement Extraction**: Extract key statements that need verification. Each statement should be independently complete, contain specific factual elements, and be verifiable through web search.
2. **Quick Verification**: Search and verify extracted statements. Prioritize keyword searches, cross-reference multiple sources, focus on officially published information.
3. **Issue Marking**: Classify verification results:
   - ✅ **Confirmed**: Multiple reliable sources consistent
   - ⚠️ **Questionable**: Sources contradict or cannot be confirmed
   - ❌ **Incorrect**: Clearly inconsistent with reliable sources
4. **Correction**: For problematic content, provide specific correction suggestions. If issues found, correct the original article text and update the docx file.

#### Fact-Check Report Format

```
## Fact-Check Report

### Verification Overview
- Article Title: [Title]
- Statements Extracted: [X] items
- Verification Results: ✅ [X] confirmed / ⚠️ [X] questionable / ❌ [X] incorrect

### Verification Details

**Statement 1:** [Specific statement content]
- Verification Result: ✅ Confirmed
- Verification Source: [Source]

**Statement 2:** [Specific statement content]
- Verification Result: ❌ Incorrect
- Issue Description: [Specific issue]
- Correct Information: [Correct content]
- Correction Suggestion: Change "..." to "..."

### Correction List
[If corrections needed, list specific modification suggestions]

### Verification Conclusion
[Overall assessment of article's factual accuracy]
```

**Principles:**
- Efficiency First: Focus on key facts, don't over-verify
- Better Safe Than Sorry: Mark as questionable if cannot confirm, don't judge lightly
- Constructive Feedback: Provide correction solutions when issues found

---

## Final Output Specification

Deliver to user:
1. **Tracking Summary**: Brief description of core findings from this tracking (within 100 words)
2. **Trending Topics List**: List of mined trending topics
3. **Complete Article**: Long-form article with images, saved as docx
4. **Fact Check Report**: Verification results and correction records (if any)

## Tool References

| Tool | Used In | Purpose |
|------|---------|---------|
| `WebSearch` | Steps 1, 2, 4, 6 | Search for sources, verify facts |
| `WebFetch` | Steps 2, 4 | Read original source content in depth |
| `images_search_and_download` | Step 5 | Add 2-3 relevant images to article |
| `convert_file` | Step 5 | Convert markdown to docx format |
| `Write` | Step 5 | Save article as markdown file |
| `Agent` | Step 4 | Parallelize deep searches for multiple topics |

## Scheduled Task Adaptation

This skill supports scheduled task invocation. In scheduled scenarios:
- Automatically continue tracking using previous tracking theme
- Focus on "new" and "changed" content
- Output incremental update report

## Common Mistakes to Avoid

- **Skipping the search verification** in Step 1 — always search before judging ambiguity
- **Using report/publication time** instead of actual event occurrence time for timeliness filtering
- **Including loosely related topics** — trending topics must be directly relevant to the user's tracked theme
- **Writing vague topic titles** like "AI updates" — be specific with names, dates, data
- **Fabricating quotes or data** — all information must come from sources
- **Parallelizing steps that must be serial** — only Step 4 can be parallelized
- **Using preachy or stiff writing style** — maintain internet appeal and brisk pace
- **Forgetting to fact-check** — Step 6 is mandatory, not optional
- **Outputting topics older than 5 days** — strict timeliness filtering required
